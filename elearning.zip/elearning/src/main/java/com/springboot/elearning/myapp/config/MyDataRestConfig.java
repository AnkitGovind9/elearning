package com.springboot.elearning.myapp.config;



import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.metamodel.EntityType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurer;
import org.springframework.http.HttpMethod;

import com.springboot.elearning.myapp.entity.Course;
import com.springboot.elearning.myapp.entity.CourseCategory;

@Configuration
public class MyDataRestConfig implements RepositoryRestConfigurer{
	
	
	private EntityManager entityManager;
	
	@Autowired
	public MyDataRestConfig(EntityManager theEntityManager)
	{
		entityManager=theEntityManager;
	}
	
@Override
public void configureRepositoryRestConfiguration(RepositoryRestConfiguration config)
{
	HttpMethod[] theUnsuportedActions ={HttpMethod.PUT,HttpMethod.POST,HttpMethod.DELETE};
	//disable Http method for Course :PUT,POST,DELETE
	config.getExposureConfiguration().forDomainType(Course.class)
	.withItemExposure((metadata,httpMethods)->httpMethods.disable(theUnsuportedActions))
	.withCollectionExposure((metadata,httpMethods)->httpMethods.disable(theUnsuportedActions));
	
	
	//disable Http method for CourseCategory :PUT,POST,DELETE
		config.getExposureConfiguration().forDomainType(CourseCategory.class)
		.withItemExposure((metadata,httpMethods)->httpMethods.disable(theUnsuportedActions))
		.withCollectionExposure((metadata,httpMethods)->httpMethods.disable(theUnsuportedActions));
		
		//call internal helper method 
		
		exposeIds(config);
}

private void exposeIds(RepositoryRestConfiguration config) {
	// TODO Auto-generated method stub
	//expose entity ids
	
	//-get a list of all entity classes from the entity manager
	
	Set<EntityType<?>> entities=entityManager.getMetamodel().getEntities();
	
	//create an array list of entity type
	
	List<Class> entityClasses=new ArrayList<>();
	
	//get the entity type for the entities
	
	for(EntityType tempEntityType : entities)
	{
		entityClasses.add(tempEntityType.getBindableJavaType());
	}
	
	//expose the entity ids for the array of entity/domain type
	
	Class[] domainTypes=entityClasses.toArray(new Class[0]);
	config.exposeIdsFor(domainTypes);
}
}
